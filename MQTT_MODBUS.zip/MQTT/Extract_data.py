import json as JSON
from types import NoneType

def ExtractData(data):
    print(ExtractDev1Data(data=data))
    print(ExtractDev2Data(data=data))



""" ---------------------------------------------------------------------
    @name   : ExtractDev1Data
    @param  : received data 
    @returns: JSON of DEVICE1
    @date   : 01 Mar 2023
    @Tested : OK
    @brief  : Extract data of device 1 from received data
    @note   : 
--------------------------------------------------------------------- """
def ExtractDev1Data(data):
    DEVICE1 = data
    try:
        if(data["DEVICE1"] == 'Data not recieved'):
            # print(data["DEVICE1"])
            DEVICE1 = data["DEVICE1"]
        elif(isinstance(data,str)):
            DEVICE1 = JSON.loads(data["DEVICE1"])
            # print(DEVICE1)
        elif(isinstance(data,dict)):
            DEVICE1 = data["DEVICE1"]
            # print(DEVICE1)
    except Exception as e:
        print(e)
    return DEVICE1

""" ---------------------------------------------------------------------
    @name   : ExtractDev2Data
    @param  : received data 
    @returns: JSON of DEVICE2
    @date   : 01 Mar 2023
    @Tested : OK
    @brief  : Extract data of device 2 from received data
    @note   : 
--------------------------------------------------------------------- """
def ExtractDev2Data(data):
    DEVICE2 = data
    try:
        if(data["DEVICE2"] == 'Data not recieved'):
            # print(data["DEVICE2"])
            DEVICE1 = data["DEVICE1"]
        elif(isinstance(data,str)):
            DEVICE2 = JSON.loads(data["DEVICE2"])
            # print(DEVICE2)
        elif(isinstance(data,dict)):
            DEVICE2 = data["DEVICE2"]
            # print(DEVICE2)
    except Exception as e:
        print(e)
    return DEVICE2


